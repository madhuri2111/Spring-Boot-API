insert into pickup_order (ID, DESCRIPTION, PICKUP_DATE, PICKED)
values(10001, 'Walmart Electronics', CURRENT_DATE(), false);

insert into pickup_order (ID, DESCRIPTION, PICKUP_DATE, PICKED)
values(10002, 'Walmart Grocery', CURRENT_DATE(), false);

insert into pickup_order (ID, DESCRIPTION, PICKUP_DATE, PICKED)
values(10003, 'Target Home Decor', CURRENT_DATE(), false);

insert into pickup_order (ID, DESCRIPTION, PICKUP_DATE, PICKED)
values(10004, 'Target Electronics', CURRENT_DATE(), false);

insert into pickup_order (ID, DESCRIPTION, PICKUP_DATE, PICKED)
values(10005, 'Best Buy Security Devices', CURRENT_DATE(), false);

insert into pickup_order (ID, DESCRIPTION, PICKUP_DATE, PICKED)
values(10006,'Home Depot Wooden Logs', CURRENT_DATE(), false);