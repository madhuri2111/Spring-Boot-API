package com.springboot.firstspringbootapp.order;

import org.springframework.data.jpa.repository.JpaRepository;

//this interface provides all methods to save data in database
//we can add more methods based on system requirements
public interface OrderRepository extends JpaRepository<PickupOrder, Integer>{

}
