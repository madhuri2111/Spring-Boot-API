package com.springboot.firstspringbootapp.order;


import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Size;

//This is the main object class
//It has the corresponding DB table with all properties as table columns
@Entity(name="PickupOrder")
public class PickupOrder {
	
	@Id
	@GeneratedValue
	private int id;
	@Size(min=10, message="Enter atleast 10 characters")
	private String description;
	private LocalDate pickupDate;
	private boolean picked;
	
	//default constructor for spring initialization
	public PickupOrder() {
		super();
	}
	
	//constructor with values
	public PickupOrder(int id, String description, LocalDate pickupDate, boolean picked) {
		super();
		this.id = id;
		this.description = description;
		this.pickupDate = pickupDate;
		this.picked = picked;
	}
	public int getId() {
		return id;
	}
	public String getDescription() {
		return description;
	}
	public LocalDate getPickupDate() {
		return pickupDate;
	}
	public boolean isPicked() {
		return picked;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public void setPickupDate(LocalDate pickupDate) {
		this.pickupDate = pickupDate;
	}
	public void setPicked(boolean picked) {
		this.picked = picked;
	}

	@Override
	public String toString() {
		return "Order [id=" + id + ", description=" + description + ", pickupDate=" + pickupDate + ", picked=" + picked
				+ "]";
	}	

}
