package com.springboot.firstspringbootapp.order;

import java.time.LocalDate;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import jakarta.validation.Valid;

@Controller
public class OrderControllerJpa {

	//service class which will interact with h2 db
	private OrderRepository orderRepository;

	//constructor
	public OrderControllerJpa(OrderRepository repository) {
		super();
		this.orderRepository = repository;
	}
	
	@RequestMapping("list-pickuporders")
	public String listAllOrders(ModelMap model) {
		//All values in db are entered using data.sql
		// this will return all orders from db
		List<PickupOrder> orders = orderRepository.findAll();
		model.addAttribute("pickuporders", orders);
		return "listpickuporders";
	}
	
	@RequestMapping(value = "add-pickuporder", method = RequestMethod.GET)
	public String showNewOrderPage(ModelMap model) {
		//this will create empty order 
		//and will show on page where user needs to input expected values
		PickupOrder order = new PickupOrder(0, "", LocalDate.now().plusYears(1), false);
		model.put("pickuporder", order);
		return "pickuporder";
	}
	
	@RequestMapping(value = "add-pickuporder", method = RequestMethod.POST)
	public String addNewOrder(ModelMap model, @Valid PickupOrder order, BindingResult result) {
		//checks for error
		//in case of error it will show new order page 
		//where user has to enter correct values
		if(result.hasErrors()) {
			return "pickuporder";
		}
		//if new order entry is as expected then save Order in db
		orderRepository.save(order); //this will save data to h2 db
		return "redirect:list-pickuporders";
	}
	
	@RequestMapping("delete-pickuporder")
	public String deleteOrder(@RequestParam int id) {
		//Delete Order
		orderRepository.deleteById(id);
		return "redirect:list-pickuporders";
	}
	
	@RequestMapping("update-pickuporder")
	public String showUpdateOrderPage(@RequestParam int id, ModelMap model) {
		//update the Order
		PickupOrder order = orderRepository.findById(id).get();
		model.addAttribute("pickuporder", order);
		return "pickuporder";
	}
	
	@RequestMapping(value = "update-pickuporder", method = RequestMethod.POST)
	public String updateOrder(ModelMap model, @Valid PickupOrder order, BindingResult result) {
		//check for error
		//in case of error it will show update order page
		//where user has to enter correct values
		if(result.hasErrors()) {
			return "pickuporder";
		}
		//if no error then save the updated order
		orderRepository.save(order);
		return "redirect:list-pickuporders";
	}	
	
}
